int main() {
    int a = 3;
    int b = 4;
    int c = 0;
    c = a % 2 + b * 5;
    printf("%d\n", c);
    return 0;
}