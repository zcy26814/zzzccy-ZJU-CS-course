int main() {
    int a = 3;
    int b = 5;
    if(a % 2 == b % 2)
        println("YES");
    else
        println("NO");
    return 0;
}